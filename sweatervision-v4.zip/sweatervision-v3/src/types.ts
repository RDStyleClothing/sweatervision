export type OutputMode = 'edit' | 'render' | 'sketch' | 'sales_sheet';

export interface PantoneColor {
  code: string;
  name: string;
  hex: string;
}

export interface ColorState {
  pantone: string;
  selectedHex: string;
  colorName: string;
  colorCode: string;
  useCompensation: boolean;
  wasEyedropped: boolean;
}

export interface HistoryItem {
  id: string;
  styleKey: string;        // which style this belongs to
  prompt: string;
  image: string;
  label?: string;
  metadata?: Record<string, string>;
  version: number;
  createdAt: number;
}

export interface StyleBucket {
  key: string;             // unique id
  originalImage: string;
  label: string;           // style name/number entered by user
  aspectWarning: boolean;  // true if image was not portrait
  history: HistoryItem[];
  versionCounter: number;
}

export interface CollectionPalette {
  id: string;
  pantone: string;
  hex: string;
  name: string;
  code: string;
  savedAt: number;
}

export interface AppSettings {
  geminiApiKey: string;
  anthropicApiKey: string;
  showRateLimitTimer: boolean;
}
