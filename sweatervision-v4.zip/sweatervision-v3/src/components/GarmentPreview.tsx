import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Loader2, MousePointer2, Download, Layout, Columns, SlidersHorizontal, RefreshCcw, Info } from 'lucide-react';
import { cn, downloadImage, downloadComparisonImage, generateLabel, generateFilename } from '../lib/utils';

interface GarmentPreviewProps {
  originalImage: string | null;
  modifiedImage: string | null;
  isProcessing: boolean;
  processingStep?: string;
  label?: string;
  metadata?: Record<string, string>;
  version?: number;
  baseContext?: string;   // "Editing from: V2 of FW25-SWTR-08"
  onUseAsBase?: (image: string) => void;
  className?: string;
}

export const GarmentPreview: React.FC<GarmentPreviewProps> = ({
  originalImage, modifiedImage, isProcessing, processingStep,
  label, metadata, version, baseContext, onUseAsBase, className
}) => {
  const [isSliderMode, setIsSliderMode] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const fullLabel = generateLabel({ label, metadata, version });
  const filename = generateFilename({ label, metadata, version: version || 0 }, 0);
  const comparisonFilename = `comparison-${filename}`;
  const isRender = metadata?.renderMode !== 'Sales Sheet Render';

  const handleMove = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (!isSliderMode || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    setSliderPosition(Math.max(0, Math.min(100, ((x - rect.left) / rect.width) * 100)));
  }, [isSliderMode]);

  if (!originalImage) return null;

  const showSlider = !isProcessing && modifiedImage && isSliderMode;

  return (
    <div className={cn('space-y-4', className)}>
      {/* Base context indicator */}
      {baseContext && (
        <div className="flex items-center gap-2 px-3 py-2 bg-brand-accent/10 border border-brand-accent/20">
          <Info className="w-3.5 h-3.5 text-brand-accent flex-shrink-0" />
          <span className="font-mono text-[9px] uppercase tracking-widest text-brand-accent">{baseContext}</span>
        </div>
      )}

      {/* View toggle */}
      {!isProcessing && modifiedImage && (
        <div className="flex justify-center pt-4">
          <div className="inline-flex bg-brand-ink/5 p-1 rounded-full border border-brand-ink/5">
            {[
              { label: 'Grid View', icon: Columns, mode: false },
              { label: 'Slider', icon: SlidersHorizontal, mode: true },
            ].map(({ label: lbl, icon: Icon, mode }) => (
              <button key={lbl} onClick={() => setIsSliderMode(mode)}
                className={cn('px-6 py-2 rounded-full font-display text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all',
                  isSliderMode === mode ? 'bg-white text-brand-ink shadow-sm' : 'text-brand-ink/40 hover:text-brand-ink')}>
                <Icon className="w-3.5 h-3.5" /> {lbl}
              </button>
            ))}
          </div>
        </div>
      )}

      {showSlider ? (
        <div className="relative group p-2">
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-brand-ink text-white px-4 sm:px-6 py-2 rounded-full font-display text-[9px] sm:text-[10px] font-bold uppercase tracking-widest z-20 flex items-center gap-3 sm:gap-6 whitespace-nowrap shadow-xl max-w-[95%]">
            {fullLabel && <span className="text-white/60 hidden sm:inline truncate max-w-[150px]">{fullLabel}</span>}
            <div className="flex items-center gap-3 sm:gap-6 border-l border-white/20 pl-3 sm:pl-6">
              {onUseAsBase && (
                <button onClick={() => onUseAsBase(modifiedImage!)}
                  className="hover:text-brand-accent transition-colors flex items-center gap-1.5 cursor-pointer">
                  <RefreshCcw className="w-3 h-3" /> <span>Set as Base</span>
                </button>
              )}
              <button onClick={() => downloadImage(modifiedImage!, filename, { label: fullLabel, isRender })}
                className="hover:text-brand-accent transition-colors flex items-center gap-1.5 cursor-pointer">
                <Download className="w-3 h-3" /> <span>Save</span>
              </button>
            </div>
          </div>
          <div ref={containerRef} onMouseMove={handleMove} onTouchMove={handleMove}
            className={cn('relative rounded-2xl overflow-hidden aspect-[3/4] max-h-[65vh] mx-auto cursor-ew-resize select-none border border-brand-ink/5',
              isRender ? 'transparency-checkerboard' : 'bg-white')}>
            <img src={originalImage} alt="Original" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0 w-full h-full overflow-hidden"
              style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}>
              <img src={modifiedImage!} alt="Modified" className="absolute inset-0 w-full h-full object-cover" />
            </div>
            <div className="absolute inset-y-0 w-px bg-brand-ink/10 z-10 pointer-events-none" style={{ left: `${sliderPosition}%` }}>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-white rounded-full flex items-center justify-center border border-brand-ink/10 shadow-2xl">
                <MousePointer2 className="w-4 h-4 text-brand-ink" />
              </div>
            </div>
            <div className="absolute bottom-6 left-6 font-display text-[9px] font-bold uppercase tracking-widest bg-white/80 backdrop-blur-sm text-brand-ink px-3 py-1 rounded-full pointer-events-none">Original</div>
            <div className="absolute bottom-6 right-6 font-display text-[9px] font-bold uppercase tracking-widest bg-brand-ink/80 backdrop-blur-sm text-white px-3 py-1 rounded-full pointer-events-none">AI Render</div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-2">
          <div className="relative group aspect-[3/4] overflow-hidden rounded-2xl border border-brand-ink/5">
            <div className="absolute top-4 left-4 z-10">
              <span className="bg-brand-ink/10 backdrop-blur-md text-brand-ink px-3 py-1 rounded-full font-display text-[9px] font-bold uppercase tracking-widest">Reference</span>
            </div>
            <img src={originalImage} alt="Original" className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105" />
          </div>

          <div className={cn('relative aspect-[3/4] overflow-hidden rounded-2xl border border-brand-ink/5 flex items-center justify-center',
            isRender ? 'transparency-checkerboard' : 'bg-white')}>
            <AnimatePresence mode="wait">
              {isProcessing ? (
                <motion.div key="loader" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-8 px-12 text-center">
                  <div className="relative">
                    <div className="w-20 h-20 border-t-2 border-brand-accent rounded-full animate-spin" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 border-t-2 border-brand-ink/10 rounded-full animate-spin rotate-45" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <p className="font-display text-[10px] font-bold uppercase tracking-[0.3em] text-brand-ink">System Rendering</p>
                    <p className="font-display text-[9px] font-medium uppercase tracking-widest text-brand-accent animate-pulse">
                      {processingStep || 'Initializing...'}
                    </p>
                  </div>
                </motion.div>
              ) : modifiedImage ? (
                <div className="relative group w-full h-full">
                  <div className="absolute top-4 left-4 z-10 flex gap-2">
                    <span className="bg-brand-accent text-white px-3 py-1 rounded-full font-display text-[9px] font-bold uppercase tracking-widest shadow-lg">AI Generated</span>
                    {fullLabel && (
                      <span className="bg-white/80 backdrop-blur-md text-brand-ink px-3 py-1 rounded-full font-display text-[9px] font-bold uppercase tracking-widest shadow-sm truncate max-w-[140px]">
                        {fullLabel}
                      </span>
                    )}
                  </div>
                  <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
                    {onUseAsBase && (
                      <button onClick={() => onUseAsBase(modifiedImage)} title="Set as Base for further edits"
                        className="p-3 bg-white hover:bg-brand-accent hover:text-white rounded-full shadow-xl transition-all">
                        <RefreshCcw className="w-4 h-4" />
                      </button>
                    )}
                    <button onClick={() => downloadImage(modifiedImage, filename, { label: fullLabel, isRender })} title="Download"
                      className="p-3 bg-white hover:bg-brand-accent hover:text-white rounded-full shadow-xl transition-all">
                      <Download className="w-4 h-4" />
                    </button>
                    <button onClick={() => downloadComparisonImage(originalImage!, modifiedImage, comparisonFilename, fullLabel)} title="Download Comparison"
                      className="p-3 bg-white hover:bg-brand-accent hover:text-white rounded-full shadow-xl transition-all">
                      <Layout className="w-4 h-4" />
                    </button>
                  </div>
                  <motion.img key="modified" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}
                    src={modifiedImage} alt="Modified" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="text-center p-12 space-y-4 opacity-20">
                  <div className="w-12 h-12 border border-brand-ink rounded-full mx-auto flex items-center justify-center">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                  <p className="font-display text-[10px] font-bold uppercase tracking-[0.2em]">Standby For Render</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}
    </div>
  );
};
