import type { ColorState, OutputMode } from '../types';
import { findPantoneByInput, getHexFromPantone, getCompensatedColor, getDynamicColorDescriptor, getNearestPantoneFromHex } from './pantone';

interface BuildPromptOptions {
  colorState: ColorState;
  target: string;
  activePresets: string[];
  userPrompt: string;
  fabricDescription: string;
  mode: OutputMode;
  isForceAsIs: boolean;
}

// Claude Sonnet API call to build a precision color + garment instruction
export async function buildClaudePrompt(
  apiKey: string,
  options: BuildPromptOptions
): Promise<string> {
  const { colorState, target, activePresets, userPrompt, fabricDescription, mode, isForceAsIs } = options;

  // Build a structured input for Claude
  const colorInfo = buildColorInfo(colorState);
  const modeDesc = { edit: 'Edit (model shot)', render: '3D Render (ghost mannequin)', sketch: 'Technical Flat Sketch', sales_sheet: 'Sales Sheet' }[mode];

  const systemPrompt = `You are an expert fashion AI prompt engineer specializing in garment color reproduction for e-commerce and sales materials. Your job is to write highly precise image generation prompts for Gemini that produce photorealistic garment renders with exact color fidelity.

Rules:
- Write ONE single paragraph of instructions. No bullet points, no headers.
- Be extremely specific about color: always include hex code, color descriptor, and lighting conditions.
- For color changes: emphasize that the ENTIRE garment fabric must be uniformly recolored with zero residual undertones from the original.
- Lighting must always be: bright, diffuse, high-exposure commercial studio front lighting to preserve color accuracy on screen.
- Keep it under 120 words. Dense and precise beats verbose.`;

  const userMsg = `Write a Gemini image generation prompt for:
Mode: ${modeDesc}
Target part: ${target || 'garment'}
Color change requested: ${activePresets.includes('Change Color') ? 'YES' : 'NO'}
${colorInfo}
${fabricDescription ? `Fabric: ${fabricDescription}` : ''}
${userPrompt ? `Additional instructions: ${userPrompt}` : ''}
${isForceAsIs ? 'IMPORTANT: Render as-is, preserve all original colors exactly.' : ''}
${mode === 'sketch' ? 'IMPORTANT: Technical flat sketch output, white background, no color fills.' : ''}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        system: systemPrompt,
        messages: [{ role: 'user', content: userMsg }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(`Claude API error ${response.status}: ${(err as any)?.error?.message || response.statusText}`);
    }

    const data = await response.json();
    const text = data.content?.[0]?.text?.trim();
    if (!text) throw new Error('Claude returned empty prompt');
    return text;
  } catch (err) {
    console.warn('Claude prompt build failed, falling back to local prompt:', err);
    return buildLocalPrompt(options);
  }
}

function buildColorInfo(cs: ColorState): string {
  if (!cs.pantone && cs.selectedHex === '#000000' && !cs.wasEyedropped) return 'No color change.';

  if (cs.wasEyedropped) {
    return `Color: exact hex ${cs.selectedHex} (eyedropped — no Pantone variance, 100% precision match required)`;
  }

  if (cs.pantone.trim()) {
    const match = findPantoneByInput(cs.pantone);
    const baseHex = match ? match.hex : getHexFromPantone(cs.pantone);
    const targetHex = cs.useCompensation ? getCompensatedColor(baseHex) : baseHex;
    const descriptor = getDynamicColorDescriptor(targetHex);
    return `Color: Pantone ${cs.pantone.trim()}${match ? ` (${match.name})` : ''}, target hex ${targetHex}, described as ${descriptor}`;
  }

  const targetHex = cs.useCompensation ? getCompensatedColor(cs.selectedHex) : cs.selectedHex;
  const nearest = getNearestPantoneFromHex(cs.selectedHex);
  const descriptor = getDynamicColorDescriptor(targetHex);
  return `Color: hex ${targetHex} (nearest Pantone: ${nearest.code} ${nearest.name}), described as ${descriptor}`;
}

// Fallback local prompt builder (no Claude needed)
export function buildLocalPrompt(options: BuildPromptOptions): string {
  const { colorState, target, activePresets, userPrompt, fabricDescription, mode, isForceAsIs } = options;
  const parts: string[] = [];
  const tgt = target || 'garment';

  if (mode === 'sales_sheet') {
    parts.push('Convert all sketches on this full page sales sheet into photorealistic 3D renders');
    if (fabricDescription.trim()) parts.push(`using ${fabricDescription} fabric throughout`);
    return parts.join(', ');
  }

  if (isForceAsIs) {
    return `Strictly render the ${tgt} as is with the exact same original pattern, print, and colors`;
  }

  if (activePresets.includes('Change Color')) {
    const colorInstruction = buildColorInstruction(colorState, tgt);
    if (colorInstruction) parts.push(colorInstruction);
  }

  if (fabricDescription.trim() && (mode === 'render')) {
    parts.push(`render using ${fabricDescription} fabric texture`);
  }

  if (mode === 'render' && !activePresets.includes('Change Design')) {
    parts.push(`strictly maintain the exact same original pattern and print details of the ${tgt}`);
  }

  if (mode === 'sketch') {
    parts.push(`produce a clean technical flat sketch with white fill, black construction lines, symmetrical front view`);
  }

  if (userPrompt.trim()) parts.push(userPrompt.trim());

  const joined = parts.join(', ');
  return joined.charAt(0).toUpperCase() + joined.slice(1);
}

function buildColorInstruction(cs: ColorState, target: string): string {
  if (cs.wasEyedropped) {
    const hex = cs.selectedHex;
    const desc = getDynamicColorDescriptor(hex);
    return `completely and strictly recolor the entire fabric of the ${target} to be exactly hexadecimal color ${hex}, which is a ${desc}. Use ONLY this exact color as reference with 100% precision and zero variance. Completely replace the original garment color leaving no residual undertones. Render under bright diffuse commercial studio lighting.`;
  }

  if (cs.pantone.trim()) {
    const match = findPantoneByInput(cs.pantone);
    const baseHex = match ? match.hex : getHexFromPantone(cs.pantone);
    const targetHex = cs.useCompensation ? getCompensatedColor(baseHex) : baseHex;
    const desc = getDynamicColorDescriptor(targetHex);
    const name = match?.name || 'Custom';
    return `completely and strictly recolor the entire fabric of the ${target} to Pantone ${cs.pantone.trim()} (${name}), a ${desc}, target hex ${targetHex}. Replace all original color and undertones. Render under bright diffuse high-key commercial studio lighting so flat areas match ${targetHex} precisely.`;
  }

  const targetHex = cs.useCompensation ? getCompensatedColor(cs.selectedHex) : cs.selectedHex;
  const nearest = getNearestPantoneFromHex(cs.selectedHex);
  const desc = getDynamicColorDescriptor(targetHex);
  return `completely recolor the entire fabric of the ${target} to hex ${targetHex} (nearest Pantone ${nearest.code} ${nearest.name}), a ${desc}. Replace all original color. Render under bright diffuse studio lighting to match ${targetHex} on screen.`;
}
