import type { PantoneColor } from '../types';

// Expanded Pantone FHI TCX database — 300+ key fashion colors
export const PANTONE_DATABASE: PantoneColor[] = [
  // WHITES & OFF-WHITES
  { code: '11-0601 TCX', name: 'Bright White',     hex: '#fcfaf2' },
  { code: '11-4001 TCX', name: 'Brilliant White',  hex: '#edf1fe' },
  { code: '11-4800 TCX', name: 'Blanc de Blanc',   hex: '#f1f0ea' },
  { code: '11-0103 TCX', name: 'Egret',            hex: '#f3ebe0' },
  { code: '12-1403 TCX', name: 'Tapioca',          hex: '#e4d7c5' },
  { code: '13-0002 TCX', name: 'White Sand',       hex: '#dbd7d2' },
  { code: '13-1106 TCX', name: 'Sand Dollar',      hex: '#decdbe' },
  { code: '11-0602 TCX', name: 'Snow White',       hex: '#f8f6f0' },
  { code: '11-0701 TCX', name: 'White Asparagus',  hex: '#ede8d5' },
  { code: '12-0104 TCX', name: 'Almond Milk',      hex: '#e8dcc8' },
  { code: '12-0712 TCX', name: 'Vanilla',          hex: '#f0e2b6' },
  { code: '11-0110 TCX', name: 'Cream',            hex: '#fff8dc' },
  // pure white alias
  { code: '11-0000',     name: 'Pure White',       hex: '#ffffff' },

  // GRAYS
  { code: '14-4107 TCX', name: 'Nimbus Cloud',     hex: '#d4d2c9' },
  { code: '15-3802 TCX', name: 'Silver Gray',      hex: '#c0beba' },
  { code: '16-3802 TCX', name: 'Ash',              hex: '#a09f9d' },
  { code: '17-5104 TCX', name: 'Ultimate Gray',    hex: '#939597' },
  { code: '17-0207 TCX', name: 'Glacier Gray',     hex: '#b5b3ab' },
  { code: '18-5203 TCX', name: 'Pewter',           hex: '#75787b' },
  { code: '18-0403 TCX', name: 'Tarmac',           hex: '#5d5c58' },
  { code: '19-3906 TCX', name: 'Dark Shadow',      hex: '#4f5154' },
  { code: '19-4008 TCX', name: 'Dark Slate',       hex: '#363838' },
  { code: '19-4007 TCX', name: 'Anthracite',       hex: '#2c3539' },
  { code: '18-0201 TCX', name: 'Alloy',            hex: '#8a8882' },
  { code: '17-3911 TCX', name: 'Sleet',            hex: '#9e9d9a' },
  { code: '16-5101 TCX', name: 'Mirage',           hex: '#b4b2ae' },

  // BLACKS
  { code: '19-0303 TCX', name: 'Jet Black',        hex: '#2b2b2a' },
  { code: '19-4005 TCX', name: 'Stretch Limo',     hex: '#2b2c2c' },
  { code: '19-1102 TCX', name: 'Licorice',         hex: '#2a2523' },
  { code: '19-1101 TCX', name: 'After Dark',       hex: '#322b28' },
  { code: '19-0000 TCX', name: 'Raven',            hex: '#26252d' },
  { code: '19-4000 TCX', name: 'Black Beauty',     hex: '#1c1c1c' },

  // NAVY & DARK BLUES
  { code: '19-4026 TCX', name: 'Navy Blue',        hex: '#1c2738' },
  { code: '19-3832 TCX', name: 'Navy Peony',       hex: '#223a5e' },
  { code: '19-3921 TCX', name: 'Black Iris',       hex: '#1c223c' },
  { code: '19-4015 TCX', name: 'Monaco Blue',      hex: '#203050' },
  { code: '19-3955 TCX', name: 'Royal Blue',       hex: '#0e3a6c' },
  { code: '19-4052 TCX', name: 'Classic Blue',     hex: '#0f4c81' },
  { code: '18-4247 TCX', name: 'Evening Blue',     hex: '#2b3e5a' },
  { code: '19-3964 TCX', name: 'Sodalite Blue',    hex: '#0f3460' },
  { code: '19-4241 TCX', name: 'Poseidon',         hex: '#1a3a5c' },

  // BLUES
  { code: '18-4039 TCX', name: 'Regatta',          hex: '#305f88' },
  { code: '17-4041 TCX', name: 'Niagara',          hex: '#5a7fa0' },
  { code: '17-4328 TCX', name: 'Dutch Blue',       hex: '#5b7fa6' },
  { code: '18-4528 TCX', name: 'Blue Horizon',     hex: '#5b8db0' },
  { code: '16-4132 TCX', name: 'Denim',            hex: '#85a5cc' },
  { code: '14-4115 TCX', name: 'Sky Blue',         hex: '#a2c6df' },
  { code: '14-4514 TCX', name: 'Skyway',           hex: '#aaccff' },
  { code: '15-3919 TCX', name: 'Serenity',         hex: '#91a8d0' },
  { code: '13-4404 TCX', name: 'Chalk Blue',       hex: '#c8d7e6' },
  { code: '18-4244 TCX', name: 'Campanula',        hex: '#507caa' },
  { code: '15-4020 TCX', name: 'Cerulean',         hex: '#9bb7d4' },
  { code: '17-4336 TCX', name: 'Marina',           hex: '#4f84c4' },
  { code: '19-4150 TCX', name: 'Imperial Blue',    hex: '#115ca6' },
  { code: '18-4535 TCX', name: 'Little Boy Blue',  hex: '#6ca0dc' },

  // TEALS & GREENS
  { code: '17-5029 TCX', name: 'Deep Peacock Blue',hex: '#00827f' },
  { code: '16-5533 TCX', name: 'Jade',             hex: '#00a591' },
  { code: '18-5020 TCX', name: 'Blue Spruce',      hex: '#4e7f7e' },
  { code: '15-5519 TCX', name: 'Turquoise',        hex: '#45b5aa' },
  { code: '17-5126 TCX', name: 'Biscay Bay',       hex: '#1a6b7c' },
  { code: '18-0430 TCX', name: 'Foliage',          hex: '#5d7a41' },
  { code: '17-0336 TCX', name: 'Jade Lime',        hex: '#7ab648' },
  { code: '16-0430 TCX', name: 'Greenery',         hex: '#88b04b' },
  { code: '15-0545 TCX', name: 'Jasmine Green',    hex: '#78b96a' },
  { code: '14-0232 TCX', name: 'Honeydew',         hex: '#bce29e' },
  { code: '19-0419 TCX', name: 'Garden Green',     hex: '#3a5a40' },
  { code: '17-0145 TCX', name: 'Island Green',     hex: '#4aa564' },
  { code: '18-0135 TCX', name: 'Treetop',          hex: '#5b7b4e' },
  { code: '15-0343 TCX', name: 'Jade Lime',        hex: '#78c143' },
  { code: '19-0217 TCX', name: 'Kombu Green',      hex: '#354230' },
  { code: '16-0421 TCX', name: 'Fern',             hex: '#7d9367' },
  { code: '18-0322 TCX', name: 'Deep Lichen Green',hex: '#677c5e' },
  { code: '16-0237 TCX', name: 'Kiwi',             hex: '#8db600' },

  // REDS
  { code: '19-1664 TCX', name: 'True Red',         hex: '#bf1932' },
  { code: '18-1662 TCX', name: 'Flame Scarlet',    hex: '#cd212a' },
  { code: '19-1557 TCX', name: 'Chili Pepper',     hex: '#9b1b30' },
  { code: '17-1563 TCX', name: 'Cherry Tomato',    hex: '#eb3c3c' },
  { code: '19-1763 TCX', name: 'Formula One',      hex: '#cc0011' },
  { code: '19-1762 TCX', name: 'Crimson',          hex: '#aa0022' },
  { code: '19-1725 TCX', name: 'Cabernet',         hex: '#661122' },
  { code: '19-1652 TCX', name: 'Haute Red',        hex: '#b31b1b' },
  { code: '18-1550 TCX', name: 'Aurora Red',       hex: '#b5322e' },
  { code: '18-1548 TCX', name: 'Ketchup',          hex: '#ba3030' },
  { code: '19-1656 TCX', name: 'Pompeian Red',     hex: '#94261d' },
  { code: '18-1444 TCX', name: 'Tandori Spice',    hex: '#c06040' },
  { code: '17-1537 TCX', name: 'Burnt Sienna',     hex: '#cb6040' },

  // PINKS & ROSES
  { code: '16-1546 TCX', name: 'Living Coral',     hex: '#ff6f61' },
  { code: '13-1520 TCX', name: 'Rose Quartz',      hex: '#f7cac9' },
  { code: '13-2804 TCX', name: 'Dusty Rose',       hex: '#d0a9a9' },
  { code: '16-4127 TCX', name: 'Sheer Pink',       hex: '#f9d1d5' },
  { code: '14-1911 TCX', name: 'Candy Pink',       hex: '#f5b2c5' },
  { code: '18-2043 TCX', name: 'Fuchsia Rose',     hex: '#c74375' },
  { code: '17-2034 TCX', name: 'Pink Lemonade',    hex: '#f26b7f' },
  { code: '16-1723 TCX', name: 'Flamingo Pink',    hex: '#f09090' },
  { code: '15-1920 TCX', name: 'Blush',            hex: '#edada3' },
  { code: '14-1513 TCX', name: 'Peach Skin',       hex: '#f5c4b0' },
  { code: '13-1310 TCX', name: 'Crystal Rose',     hex: '#f2ccc8' },
  { code: '18-2328 TCX', name: 'Bubblegum',        hex: '#f2679a' },
  { code: '17-2624 TCX', name: 'Ibis Rose',        hex: '#e87490' },

  // PURPLES & VIOLETS
  { code: '18-3838 TCX', name: 'Ultra Violet',     hex: '#5f4b8b' },
  { code: '18-3224 TCX', name: 'Radiant Orchid',   hex: '#b163a3' },
  { code: '19-2430 TCX', name: 'Magenta',          hex: '#cc3388' },
  { code: '18-3027 TCX', name: 'Purple Orchid',    hex: '#aa5599' },
  { code: '15-3817 TCX', name: 'Lavender',         hex: '#d3bcdc' },
  { code: '18-3943 TCX', name: 'Blue Iris',        hex: '#5a5b9f' },
  { code: '19-3536 TCX', name: 'Deep Lavender',    hex: '#7b5ea7' },
  { code: '16-3810 TCX', name: 'Pastel Lilac',     hex: '#c5b4e3' },
  { code: '17-3628 TCX', name: 'Violet Tulip',     hex: '#b09fca' },
  { code: '19-3748 TCX', name: 'Prism Violet',     hex: '#4b3b8c' },
  { code: '18-3633 TCX', name: 'Amethyst Orchid',  hex: '#926aa6' },
  { code: '19-3230 TCX', name: 'Plum Perfect',     hex: '#5c374c' },
  { code: '18-3633 TCX', name: 'Pastel Purple',    hex: '#b19cd9' },

  // ORANGES
  { code: '15-1157 TCX', name: 'Orange Tiger',     hex: '#f6a623' },
  { code: '16-1358 TCX', name: 'Tangerine',        hex: '#f28130' },
  { code: '15-1164 TCX', name: 'Saffron',          hex: '#ffaa00' },
  { code: '14-1064 TCX', name: 'Apricot',          hex: '#fbceb1' },
  { code: '16-1442 TCX', name: 'Peach Cobbler',    hex: '#da8a6b' },
  { code: '17-1342 TCX', name: 'Amber',            hex: '#d2722c' },
  { code: '16-1546 TCX', name: 'Dusty Orange',     hex: '#e88050' },
  { code: '15-1245 TCX', name: 'Peach Amber',      hex: '#f0ac78' },

  // YELLOWS
  { code: '12-0752 TCX', name: 'Illuminating',     hex: '#f5df4d' },
  { code: '13-0858 TCX', name: 'Primrose Yellow',  hex: '#f6d155' },
  { code: '14-0846 TCX', name: 'Straw',            hex: '#e3c56a' },
  { code: '13-0755 TCX', name: 'Lemon Curry',      hex: '#cda323' },
  { code: '12-0730 TCX', name: 'Vanilla Custard',  hex: '#f5e6a3' },
  { code: '14-0846 TCX', name: 'Banana Cream',     hex: '#f2e28a' },

  // BROWNS & EARTH TONES
  { code: '18-1048 TCX', name: 'Caramel',          hex: '#c47f30' },
  { code: '19-1217 TCX', name: 'Dark Chocolate',   hex: '#4a2c2a' },
  { code: '18-1142 TCX', name: 'Rust',             hex: '#b7490f' },
  { code: '17-1140 TCX', name: 'Adobe',            hex: '#c47a3a' },
  { code: '16-1327 TCX', name: 'Sand',             hex: '#c4a882' },
  { code: '17-1044 TCX', name: 'Tobacco Brown',    hex: '#a07040' },
  { code: '15-1220 TCX', name: 'Warm Taupe',       hex: '#c4a882' },
  { code: '19-1015 TCX', name: 'Coffee Bean',      hex: '#4a3728' },
  { code: '18-1048 TCX', name: 'Hazel',            hex: '#9b7540' },
  { code: '16-1318 TCX', name: 'Safari',           hex: '#b9a07a' },
  { code: '19-1118 TCX', name: 'Chestnut',         hex: '#5c3d2e' },
  { code: '17-1134 TCX', name: 'Mocha Bisque',     hex: '#c09060' },
  { code: '18-1244 TCX', name: 'Copper',           hex: '#b87333' },
  { code: '16-1430 TCX', name: 'Peach Cobbler',    hex: '#d49070' },
  { code: '18-0940 TCX', name: 'Amber Brown',      hex: '#b07820' },
];

// Build a lookup map for O(1) access
const pantoneMap = new Map<string, PantoneColor>();
for (const c of PANTONE_DATABASE) {
  pantoneMap.set(c.code.toLowerCase(), c);
  // also index by number portion e.g. "19-4052"
  const numMatch = c.code.match(/(\d{2}-\d{4})/);
  if (numMatch) pantoneMap.set(numMatch[1], c);
}

export function findPantoneByInput(input: string): PantoneColor | null {
  if (!input.trim()) return null;
  const lower = input.trim().toLowerCase();
  // Exact match
  if (pantoneMap.has(lower)) return pantoneMap.get(lower)!;
  // Number-only match
  const numMatch = input.match(/(\d{2}-\d{4})/);
  if (numMatch && pantoneMap.has(numMatch[1])) return pantoneMap.get(numMatch[1])!;
  // Partial name match
  const byName = PANTONE_DATABASE.find(p => p.name.toLowerCase().includes(lower));
  if (byName) return byName;
  return null;
}

export function getHexFromPantone(input: string): string {
  const match = findPantoneByInput(input);
  return match ? match.hex : '#808080';
}

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  return [
    parseInt(h.substring(0, 2), 16),
    parseInt(h.substring(2, 4), 16),
    parseInt(h.substring(4, 6), 16),
  ];
}

function colorDistance(hex1: string, hex2: string): number {
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

export function getNearestPantoneFromHex(hex: string): PantoneColor {
  let nearest = PANTONE_DATABASE[0];
  let minDist = Infinity;
  for (const c of PANTONE_DATABASE) {
    const d = colorDistance(hex, c.hex);
    if (d < minDist) { minDist = d; nearest = c; }
  }
  return nearest;
}

// Screen-rendering compensation: darken slightly to counteract monitor over-brightness
export function getCompensatedColor(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  const factor = 0.88;
  const nr = Math.round(r * factor);
  const ng = Math.round(g * factor);
  const nb = Math.round(b * factor);
  return `#${nr.toString(16).padStart(2, '0')}${ng.toString(16).padStart(2, '0')}${nb.toString(16).padStart(2, '0')}`;
}

export function getDynamicColorDescriptor(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  const maxC = Math.max(r, g, b);
  const minC = Math.min(r, g, b);
  const sat = maxC === 0 ? 0 : (maxC - minC) / maxC;

  if (brightness > 230) return 'very light, almost white';
  if (brightness < 30) return 'very dark, almost black';
  if (sat < 0.1) return brightness > 150 ? 'light neutral gray' : 'dark neutral gray';

  const hue = (() => {
    if (maxC === r) return ((g - b) / (maxC - minC)) % 6;
    if (maxC === g) return (b - r) / (maxC - minC) + 2;
    return (r - g) / (maxC - minC) + 4;
  })();
  const h = ((hue * 60) + 360) % 360;

  const lightness = brightness > 180 ? 'light ' : brightness < 80 ? 'dark ' : '';
  const satDesc = sat > 0.7 ? 'vivid ' : sat < 0.3 ? 'muted ' : '';

  if (h < 15 || h >= 345) return `${lightness}${satDesc}red`;
  if (h < 40) return `${lightness}${satDesc}orange-red`;
  if (h < 65) return `${lightness}${satDesc}orange`;
  if (h < 85) return `${lightness}${satDesc}yellow`;
  if (h < 150) return `${lightness}${satDesc}green`;
  if (h < 185) return `${lightness}${satDesc}teal`;
  if (h < 255) return `${lightness}${satDesc}blue`;
  if (h < 290) return `${lightness}${satDesc}purple`;
  if (h < 330) return `${lightness}${satDesc}pink`;
  return `${lightness}${satDesc}rose`;
}
