import { GoogleGenAI } from '@google/genai';
import type { OutputMode } from '../types';

export async function modifyGarment(
  apiKey: string,
  imageBase64: string,
  prompt: string,
  mode: OutputMode,
  referenceImageBase64?: string,
  targetPart?: string,
  onRetry?: (attempt: number) => void
): Promise<string> {
  if (!apiKey) throw new Error('GEMINI_API_KEY is not set. Add it in Settings.');

  const ai = new GoogleGenAI({ apiKey });

  const mimeMatch = imageBase64.match(/^data:(image\/[a-zA-Z+]+);base64,/);
  const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
  const base64Data = imageBase64.split(',')[1];

  const parts: any[] = [{ inlineData: { data: base64Data, mimeType } }];

  if (referenceImageBase64) {
    const refMime = referenceImageBase64.match(/^data:(image\/[a-zA-Z+]+);base64,/)?.[1] || 'image/png';
    parts.push({ inlineData: { data: referenceImageBase64.split(',')[1], mimeType: refMime } });
  }

  const focusText = mode === 'sales_sheet'
    ? 'FOCUS: Process the entire image (Sales Sheet). Identify all garment sketches and render them.'
    : targetPart
      ? `FOCUS: Only modify the "${targetPart}".`
      : 'Modify the garment.';

  // ---- BACKGROUND RULES (SOP fix: Edit mode preserves background) ----
  const backgroundRule = (() => {
    if (mode === 'sales_sheet') {
      return 'SALES SHEET: Maintain the overall page layout. Each garment rendered in place. Background clean and professional.';
    }
    if (mode === 'edit') {
      return 'PRESERVE BACKGROUND AND MODEL: Do NOT alter the background, environment, lighting, or model. Only apply the requested garment change. Keep the model, backdrop, and all non-garment elements exactly as they appear in the original image.';
    }
    if (mode === 'sketch') {
      return 'FLAT SKETCH BACKGROUND: Output a professional technical flat sketch on a strictly 100% SOLID, FLAT, PURE WHITE (#FFFFFF) BACKGROUND with no shadows and no background elements.';
    }
    // render mode
    return 'GHOST MANNEQUIN BACKGROUND: The garment must appear floating on a strictly 100% SOLID, FLAT, PURE WHITE (#FFFFFF) BACKGROUND. Absolutely ZERO background scenery, floor, vignette, gradients, or shadows of any kind. Completely uniform flat white (#FFFFFF).';
  })();

  // ---- STYLE RULES ----
  const styleRule = (() => {
    if (mode === 'sales_sheet') {
      return 'STYLE: 3D Product Render. Convert every sketch into a realistic 3D rendered garment. READ ORIGINAL COLORS: Before rendering each garment, identify and preserve the exact color shown in the original sketch. Render each garment in precisely that same color unless a Global Fabric color override is specified. Add realistic fabric textures, depth, and correct lighting. All garments must be front-facing on pure white.';
    }
    if (mode === 'sketch') {
      return 'STYLE: Technical Flat Sketch. High-contrast black lines on pure white background. No shading, no fill colors, clear construction lines, symmetrical front-facing view. Clean CAD aesthetic.';
    }
    if (mode === 'edit') {
      return 'MAINTAIN STYLE: Keep all existing yarn texture, patterns, model pose, and background exactly as-is. Only apply the specific requested modification to the garment itself.';
    }
    // render
    return 'STYLE: High-resolution photorealistic 3D E-commerce Ghost Mannequin Product Shot. Natural folds and weight, entirely hollow and empty inside. CRITICAL: Force onto a volumetric 3D torso — rounded shoulders, natural chest contour, fully open circular hollow neck showing inside back collar. Straight direct front-facing camera angle. If input is a flat technical sketch, convert it into a photorealistic finished garment with high-fidelity yarn texture, knit patterns, and realistic fabric weight.';
  })();

  const ghostMannequinRules = (mode === 'render') ? `
    2. FORCE GHOST MANNEQUIN & HOLLOW COLLAR: Rendered as a premium e-commerce ghost mannequin — 3D body volume, chest depth, rounded shoulders. Neck opening must be wide, fully open, hollow, and circular showing inside back fabric. No mannequin stands, wooden necks, plastic supports, or hangers.
    3. FORCE PERFECT FRONT-FACING CAMERA ANGLE: Perfectly flat, straight, level, direct front-facing point of view, centered and perpendicular. No three-quarter angles, profile, back view, skewed perspective, or tilted posture. Symmetrical alignment mandatory.
    4. ABSOLUTELY NO HANGERS OR TAGS: Remove any hangers, hooks, wires, price tags, barcode tags, sizing tags, cords, or labels.
    5. NO SHADOWS AT ALL: No flooring, ambient shadows, drop shadows, or shadow halos. Background flat pure sterile white (#FFFFFF).` : '';

  const dimensionsRule = (mode !== 'sales_sheet' && mode !== 'edit')
    ? '8. DIMENSIONS: Strictly 3:4 portrait aspect ratio (1200px width, 1600px height). Garment centered with 15% margin from all borders.'
    : '';

  parts.push({
    text: `AI FASHION EDITOR: ${focusText}
REQUEST: "${prompt}".
${referenceImageBase64 ? 'The SECOND image is a design/style reference.' : ''}

CRITICAL RULES (ABSOLUTE COMPLIANCE — NO EXCEPTIONS):
1. ${backgroundRule}
${ghostMannequinRules}
6. ${styleRule}
7. NO MODEL OR HUMAN PARTS (render/sketch modes only): No human faces, skin, arms, legs, or models visible.
${dimensionsRule}
9. ABSOLUTE COLOR FIDELITY: If the request includes recoloring (mentions hex code or Pantone), completely overrule and discard the original garment base colors and undertones. Dye the entire garment fabric cleanly and evenly with the target hex or Pantone shade. Keep fabric rendered under bright, diffuse, high-key commercial studio lighting. Folds must have extremely soft, subtle shadows — under no circumstances allow heavy gray/black shadows to darken or mute the fabric color below the target swatch value. Flat surface colors must match the requested swatch precisely.`,
  });

  try {
    const response = await retryWithBackoff(
      () => ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-05-20',
        contents: { parts },
      }),
      onRetry
    );

    const candidate = response.candidates?.[0];
    if (!candidate) throw new Error('AI returned no candidates. May be safety filtered.');

    let textResponse = '';
    for (const part of candidate.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      if (part.text) textResponse += part.text;
    }

    if (textResponse) throw new Error(`AI returned text instead of image: ${textResponse.slice(0, 120)}`);
    throw new Error(`No image returned. Finish reason: ${candidate.finishReason || 'unknown'}`);
  } catch (error: any) {
    const msg = error?.message || '';
    const isRateLimit =
      msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') ||
      msg.toLowerCase().includes('quota') || msg.toLowerCase().includes('rate limit');
    if (isRateLimit) {
      throw new Error('RATE_LIMIT: Gemini quota reached. Add your own Gemini API key in Settings, or wait a few minutes.');
    }
    throw error;
  }
}

async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  onRetry?: (attempt: number) => void,
  retriesLeft = 3,
  attemptIndex = 0
): Promise<T> {
  const delays = [2000, 4000, 8000];
  try {
    return await fn();
  } catch (error: any) {
    const msg = error?.message || '';
    const isRateLimit =
      msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') ||
      msg.toLowerCase().includes('quota');
    if (isRateLimit && retriesLeft > 0 && attemptIndex < delays.length) {
      if (onRetry) onRetry(attemptIndex + 1);
      await new Promise(r => setTimeout(r, delays[attemptIndex]));
      return retryWithBackoff(fn, onRetry, retriesLeft - 1, attemptIndex + 1);
    }
    throw error;
  }
}
